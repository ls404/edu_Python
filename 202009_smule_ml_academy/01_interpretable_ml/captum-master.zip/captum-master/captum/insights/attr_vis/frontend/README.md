# PyTorch Captum Insights

## Development

Captum Insights frontend is built on top of React, using create-react-app.

`yarn build` to compile files.

Javascript should be prettier formatted.
CSS uses BEM syntax.
