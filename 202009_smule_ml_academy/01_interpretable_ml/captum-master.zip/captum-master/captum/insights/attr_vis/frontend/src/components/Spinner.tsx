import React from "react";
import styles from "../App.module.css";

function Spinner() {
  return <div className={styles.spinner} />;
}

export default Spinner;
