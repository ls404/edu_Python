import warnings

from .attr_vis.features import *  # noqa

warnings.warn("Deprecated. Please use captum.insights.attr_vis.features instead.")
