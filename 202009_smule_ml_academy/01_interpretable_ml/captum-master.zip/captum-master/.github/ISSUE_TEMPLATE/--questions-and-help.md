---
name: "❓ Questions and Help"
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

## ❓ Questions and Help

We have a set of listed resources available on the website and FAQ: https://captum.ai/ and https://captum.ai/docs/faq . Feel free to open an issue here on the github or in our discussion forums:

- [Discussion Forum](https://discuss.pytorch.org/c/captum)
