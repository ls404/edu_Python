GradientShap
============

.. autoclass:: captum.attr.GradientShap
    :members:

.. autoclass:: captum.attr.InputBaselineXGradient
    :members:
