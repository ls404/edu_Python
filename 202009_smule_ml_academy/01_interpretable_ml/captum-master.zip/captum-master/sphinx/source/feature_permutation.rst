Feature Permutation
=========

.. autoclass:: captum.attr.FeaturePermutation
    :members:
