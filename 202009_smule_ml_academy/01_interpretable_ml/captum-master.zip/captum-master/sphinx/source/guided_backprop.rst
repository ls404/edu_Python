Guided Backprop
=========

.. autoclass:: captum.attr.GuidedBackprop
    :members:
