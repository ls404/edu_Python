Captum Approximation
====================

.. automodule:: captum.attr._utils.approximation_methods

.. autoclass:: Riemann
    :members:
